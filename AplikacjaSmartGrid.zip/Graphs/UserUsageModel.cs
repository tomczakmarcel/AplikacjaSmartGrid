﻿namespace AplikacjaSmartGrid.Graphs
{
    public class UserUsageModel
    {
        public string? PPE { get; set; }
        public DateTime DATACZAS { get; set; }
        public double ZUZYCIE { get; set; }

    }
}
